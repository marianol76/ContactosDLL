﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ContactosDLL;  // Referencia a la librería externa que contiene las clases base

namespace GestorContactosUNY
{
    public partial class FrmPrincipal : Form
    {
        // Repositorio de contactos en memoria
        Repositorio repo = new Repositorio();

        public FrmPrincipal()
        {
            InitializeComponent(); // Inicializa componentes del formulario
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            // Cargar opciones para ComboBox de género
            cmbGenero.Items.AddRange(new string[]
            {
                "Masculino",
                "Femenino",
                "Prefiero no decirlo"
            });
            cmbGenero.SelectedIndex = -1;

            // Configurar el DataGridView con columnas manuales
            dgvContactos.AutoGenerateColumns = false;
            dgvContactos.DataSource = repo.ListaContactos;

            // Enlazar columnas con las propiedades del objeto Contacto
            dgvContactos.Columns["colNom"].DataPropertyName = "Nombres";
            dgvContactos.Columns["colApe"].DataPropertyName = "Apellidos";
            dgvContactos.Columns["colCor"].DataPropertyName = "Correo";
            dgvContactos.Columns["colTel"].DataPropertyName = "Telefono";
            dgvContactos.Columns["colDir"].DataPropertyName = "Direccion";
            dgvContactos.Columns["colGen"].DataPropertyName = "Genero";
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Valida campos obligatorios
            if (string.IsNullOrWhiteSpace(txtNombres.Text) ||
                string.IsNullOrWhiteSpace(txtApellidos.Text) ||
                cmbGenero.SelectedIndex == -1)
            {
                MessageBox.Show("Complete los campos obligatorios.");
                return;
            }

            // Crea objeto Contacto
            Genero gen = (Genero)cmbGenero.SelectedIndex;
            Contacto nuevo = new Contacto
            {
                Nombres = txtNombres.Text.Trim(),
                Apellidos = txtApellidos.Text.Trim(),
                Correo = txtCorreo.Text.Trim(),
                Telefono = mtbTelefono.Text.Trim(),
                Direccion = rtbDireccion.Text.Trim(),
                Genero = gen
            };

            // Agrega al repositorio y actualiza el grille
            repo.Agregar(nuevo);
            dgvContactos.DataSource = null;
            dgvContactos.DataSource = repo.ListaContactos;

            LimpiarCampos();
            MessageBox.Show("Cliente registrado satisfactoriamente.");
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos(); // Limpia todos los campos del formulario
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            // Verifica si hay fila seleccionada
            if (dgvContactos.CurrentRow == null)
            {
                MessageBox.Show("Seleccione un contacto para eliminar.");
                return;
            }

            // Elimina el contacto seleccionado
            Contacto seleccionado = dgvContactos.CurrentRow.DataBoundItem as Contacto;
            if (seleccionado != null)
            {
                repo.Eliminar(seleccionado);
                dgvContactos.DataSource = null;
                dgvContactos.DataSource = repo.ListaContactos;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            // Confirmar cierre luego de presionar el boton salir
            var result = MessageBox.Show("¿Está seguro que desea salir?",
                "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
                this.Close();
        }

        // Limpia los campos del formulario
        private void LimpiarCampos()
        {
            txtNombres.Clear();
            txtApellidos.Clear();
            txtCorreo.Clear();
            mtbTelefono.Clear();
            rtbDireccion.Clear();
            cmbGenero.SelectedIndex = -1;
            txtNombres.Focus();
        }
    }
}
