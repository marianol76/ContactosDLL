﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace ContactosDLL
{
    // Repositorio de contactos en memoria
    public class Repositorio
    {
        // Lista de contactos disponible para el formulario
        public BindingList<Contacto> ListaContactos { get; } = new BindingList<Contacto>();

        // Agrega un nuevo contacto
        public void Agregar(Contacto c) => ListaContactos.Add(c);

        // Elimina un contacto existente
        public void Eliminar(Contacto c) => ListaContactos.Remove(c);
    }
}
